package DesignPatternsMenu;
	
	class RepetirExpressao implements Expressao {
	    private int vezes;
	    private Expressao expressao;

	    public RepetirExpressao(int vezes, Expressao expressao) {
	        this.vezes = vezes;
	        this.expressao = expressao;
	    }

	    @Override
	    public String interpretar() {
	        StringBuilder sb = new StringBuilder();
	        String textoBase = expressao.interpretar();
	        for (int i = 0; i < vezes; i++) {
	            sb.append(textoBase);
	        }
	        return sb.toString();
	    }
	}