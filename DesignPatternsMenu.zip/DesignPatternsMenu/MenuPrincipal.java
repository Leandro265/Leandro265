package DesignPatternsMenu;

import java.util.Scanner;

public class MenuPrincipal {

 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);
     int escolha;

     do {
         System.out.println("\n--- Escolha o Programa para Rodar ---");
         System.out.println("1. Editor de Texto Simples (Interpreter Pattern)");
         System.out.println("2. Gerador de Mensagens (Factory Method Pattern)");
         System.out.println("3. Sistema de Desconto Externo (Adapter Pattern)");
         System.out.println("0. Sair");
         System.out.print("Digite sua escolha: ");

         escolha = scanner.nextInt();
         scanner.nextLine(); // Consumir a quebra de linha

         switch (escolha) {
             case 1:
                 rodarEditorTexto();
                 break;
             case 2:
                 rodarGeradorMensagens();
                 break;
             case 3:
                 rodarSistemaDesconto();
                 break;
             case 0:
                 System.out.println("Saindo do menu. Até logo!");
                 break;
             default:
                 System.out.println("Opção inválida. Tente novamente.");
         }
     } while (escolha != 0);

     scanner.close();
 }

 public static void rodarEditorTexto() {
     System.out.println("\n--- Rodando Editor de Texto Simples ---");
     String comando1 = "caixa_alta(\"hello world\")";
     Expressao expressao1 = ExpressaoParser.parse(comando1);
     System.out.println("Entrada: " + comando1);
     System.out.println("Saída: " + expressao1.interpretar());

     String comando2 = "repetir(3, \"oi\")";
     Expressao expressao2 = ExpressaoParser.parse(comando2);
     System.out.println("\nEntrada: " + comando2);
     System.out.println("Saída: " + expressao2.interpretar());
 }

 public static void rodarGeradorMensagens() {
     System.out.println("\n--- Rodando Gerador de Mensagens ---");
     Mensagem m1 = MensagemFactory.criar("boasvindas");
     System.out.println(m1.formatar("Lucas"));

     Mensagem m2 = MensagemFactory.criar("despedida");
     System.out.println(m2.formatar("Ana"));

     Mensagem m3 = MensagemFactory.criar("agradecimento");
     System.out.println(m3.formatar("Carlos"));

     try {
         Mensagem m4 = MensagemFactory.criar("saudacao");
         System.out.println(m4.formatar("Maria"));
     } catch (IllegalArgumentException e) {
         System.out.println("Erro: " + e.getMessage());
     }
 }

 public static void rodarSistemaDesconto() {
     System.out.println("\n--- Rodando Sistema de Desconto Externo ---");
     double valorOriginal = 200.0;
     double percentualDesconto = 10.0;

     CalculadoraDesconto calculadora = new DescontoAdapter();
     double valorComDesconto = calculadora.calcular(valorOriginal, percentualDesconto);

     System.out.println("Entrada: valor = " + valorOriginal + ", percentual = " + (int)percentualDesconto);
     System.out.printf("Saída: Valor com desconto: R$%.2f%n", valorComDesconto);
 }
}
