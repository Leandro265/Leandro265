package DesignPatternsMenu;

import java.util.HashMap;
import java.util.Map;

class MensagemFactory {
 private static final Map<String, Mensagem> mensagens = new HashMap<>();

 static {
     mensagens.put("boasvindas", new MensagemBoasVindas());
     mensagens.put("despedida", new MensagemDespedida());
     mensagens.put("agradecimento", new MensagemAgradecimento());
 }

 public static Mensagem criar(String tipo) {
     Mensagem mensagem = mensagens.get(tipo.toLowerCase());
     if (mensagem != null) {
         return mensagem;
     }
     throw new IllegalArgumentException("Tipo de mensagem desconhecido: " + tipo);
 }
}