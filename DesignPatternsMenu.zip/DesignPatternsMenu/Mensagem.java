package DesignPatternsMenu;

public interface Mensagem {
    String formatar(String nome);
}