package DesignPatternsMenu;

class TerminalExpressao implements Expressao {
 private String texto;

 public TerminalExpressao(String texto) {
     this.texto = texto;
 }

 @Override
 public String interpretar() {
     return texto;
 }
}