package DesignPatternsMenu;

class CaixaAltaExpressao implements Expressao {
 private Expressao expressao;

 public CaixaAltaExpressao(Expressao expressao) {
     this.expressao = expressao;
 }

 @Override
 public String interpretar() {
     char[] caracteres = expressao.interpretar().toCharArray();
     char[] resultado = new char[caracteres.length];
     for (int i = 0; i < caracteres.length; i++) {
         if (caracteres[i] >= 'a' && caracteres[i] <= 'z') {
             resultado[i] = (char) (caracteres[i] - 32);
         } else {
             resultado[i] = caracteres[i];
         }
     }
     return new String(resultado);
 }
}