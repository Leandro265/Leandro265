package DesignPatternsMenu;

interface CalculadoraDesconto {
 double calcular(double valor, double percentual);
}