package DesignPatternsMenu;

//ExpressaoParser.java
class ExpressaoParser {
 public static Expressao parse(String comando) {
     if (comando.startsWith("caixa_alta(")) {
         String texto = comando.substring("caixa_alta(".length(), comando.length() - 2);
         return new CaixaAltaExpressao(new TerminalExpressao(texto));
     } else if (comando.startsWith("repetir(")) {
         int virgulaIndex = comando.indexOf(',');
         int parentesesIndex = comando.indexOf(')');
         if (virgulaIndex > 0 && parentesesIndex > virgulaIndex) {
             int vezes = Integer.parseInt(comando.substring("repetir(".length(), virgulaIndex).trim());
             String texto = comando.substring(virgulaIndex + 1, parentesesIndex).trim();
             if (texto.startsWith("\"") && texto.endsWith("\"")) {
                 texto = texto.substring(1, texto.length() - 1);
             }
             return new RepetirExpressao(vezes, new TerminalExpressao(texto));
         }
     }
     throw new IllegalArgumentException("Comando inválido: " + comando);
 }
}