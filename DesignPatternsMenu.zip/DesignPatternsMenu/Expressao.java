package DesignPatternsMenu;

interface Expressao {
 String interpretar();
}