package DesignPatternsMenu;

class MensagemAgradecimento implements Mensagem {
 @Override
 public String formatar(String nome) {
     return "Obrigado, " + nome + ", pela sua atenção.";
 }
}